import React from "react";

function Header(){
    return (
    <div>
      <nav className="navbar navbar-default">
        <div className="container-fluid">
          <div className="navbar-header">
            <a className="navbar-brand" href="/">DAILY JOURNAL</a>
          </div>
            <ul className="navbar-nav ">

              <li class="nav-item active" id="home"><a class="nav-link" aria-current="page" href="/">HOME</a></li>
              <li class="nav-item" id="compose"><a class="nav-link" href="/compose">COMPOSE</a></li>
              <li class="nav-item" id="about"><a class="nav-link" href="/about">ABOUT US</a></li>
              <li class="nav-item" id="contact"><a class="nav-link" href="/contact">CONTACT US</a></li>
              <li class="nav-item" id="login"><a class="nav-link" href="/login">LOG IN</a></li>
            </ul>
        </div>
      </nav>
    </div>
    )
}
export default Header;