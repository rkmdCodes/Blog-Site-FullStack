import React from "react";

function Footer() {
    return (
        <div>
            <div className="footer-padding"></div>
            <div className="footer">
                <p>Made with ❤️ in India</p>
            </div>
        </div >
    )
}
export default Footer;